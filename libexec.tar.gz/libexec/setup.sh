

apt-get  update 

apt-get install nagios-nrpe-server nagios-plugins libssl-dev  -y

mkdir -p /opt/hex/nagios/plugins/
#mkdir -p /tmp/nagios-plugins



cp -rvf  /tmp/nagios-plugins/libexec/* /opt/hex/nagios/plugins/

cp -rvf /tmp/nagios-plugins/libexec/nrpe.cfg   /etc/nagios/nrpe.cfg

service nagios-nrpe-server restart




